<html>
    <body>
        Welcome to TradingCardDB!<br /><br />
        
        <form action="form.php">
            <input type="submit" value="Add a Card" />
        </form>
        
        <form action="delete.php">
            <input type="submit" value="Delete a Card" />
        </form>
               
        <form action="view.php">
            <input type="submit" value="View all cards" />
        </form>       
               
        <form action="search.php">
            <input type="submit" value="Look up card information" />
        </form>
        
        <form action="lists.php">
            <input type="submit" value="Lists" />
        </form>
        
    </body>
</html>